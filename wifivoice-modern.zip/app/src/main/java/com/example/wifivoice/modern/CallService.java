package com.example.wifivoice.modern;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioFocusRequest;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.media.audiofx.AcousticEchoCanceler;
import android.media.audiofx.NoiseSuppressor;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Process;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.widget.Toast;

/**
 * 待受(着信受付)・呼び出し制御・音声送受信をまとめた前面サービス。
 *
 * 通信方式はSH-02D用(Android 2.3版)と同じ:
 *   UDPポート50005、先頭2バイト [0x57][種別]、音声は8kHz/モノラル/16bit PCMを20ms(320バイト)ごと。
 * そのため旧版アプリとも相互に通話できる。
 *
 * 現代のAndroid向けの考慮:
 *  - 待受はバックグラウンド制限を避けるため前面サービス(specialUse)+通知で行う
 *  - 通話中はマイク型の前面サービスに切り替える(バックグラウンドでの録音に必要)
 *  - 着信は通知(フルスクリーンインテント)で画面を出す
 *  - ネットワーク処理はすべてメインスレッド外(専用スレッド)
 *  - Wi-Fiのネットワークにプロセスを結び付け、モバイル通信が優先されても端末間通信が通るようにする
 *  - 通話用のオーディオ設定(MODE_IN_COMMUNICATION / 音声通信用ソース / エコー除去)
 */
public class CallService extends Service {

    public static final int IDLE = 0;
    public static final int CALLING = 1;   // 発信中
    public static final int RINGING = 2;   // 着信中
    public static final int IN_CALL = 3;   // 通話中

    public static final String ACTION_HANGUP = "com.example.wifivoice.modern.HANGUP";
    public static final String ACTION_ANSWER = "com.example.wifivoice.modern.ANSWER";

    public interface Listener {
        /** メインスレッドから呼ばれる */
        void onStateChanged();

        void onMessage(String message);
    }

    public class LocalBinder extends Binder {
        public CallService getService() {
            return CallService.this;
        }
    }

    // --- プロトコル (旧版と共通) ---
    static final int PORT = 50005;
    private static final byte MAGIC = 0x57;
    private static final int T_VOICE = 0x01;
    private static final int T_INVITE = 0x10;
    private static final int T_RINGING = 0x11;
    private static final int T_ACCEPT = 0x12;
    private static final int T_REJECT = 0x13;
    private static final int T_BYE = 0x14;
    private static final int T_BUSY = 0x15;

    private static final int SAMPLE_RATE = 8000;
    private static final int FRAME_BYTES = 320; // 20ms
    private static final int HEADER = 2;

    private static final long CALL_TIMEOUT = 30000;
    private static final long RING_TIMEOUT = 5000;
    private static final long VOICE_TIMEOUT = 8000;

    // --- 通知 ---
    private static final int NOTIF_FG = 1;
    private static final int NOTIF_INCOMING = 2;
    private static final int NOTIF_MISSED = 3;
    private static final String CH_STANDBY = "standby";
    private static final String CH_INCOMING = "incoming";
    private static final String CH_MISSED = "missed";

    private final LocalBinder binder = new LocalBinder();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Listener listener;

    private NotificationManager nm;
    private AudioManager am;
    private ConnectivityManager cm;
    private WifiManager wifi;

    // --- 状態 (メインスレッドのみ更新) ---
    private int state = IDLE;
    private volatile InetAddress peer;
    private boolean remoteRinging;
    private long callStart;
    private long lastInvite;
    private long connectedAt;
    private volatile long lastVoice;
    private volatile boolean speakerOn;
    private volatile String ownIp;
    private boolean destroying;

    // --- ネットワーク ---
    private volatile DatagramSocket socket;
    private volatile boolean alive;
    private Thread recvThread;
    /** 制御パケットの送信・ソケットの開閉専用。メインスレッドでは通信しない */
    private final ExecutorService netExec = Executors.newSingleThreadExecutor();
    private ConnectivityManager.NetworkCallback netCallback;
    private Network wifiNetwork;

    // --- 音声 ---
    private final Object audioLock = new Object();
    private volatile boolean audioOn;
    private AudioRecord recorder;
    private AudioTrack track;
    private Thread sendThread;
    private AcousticEchoCanceler aec;
    private NoiseSuppressor ns;
    private AudioFocusRequest focusRequest;
    private final AudioManager.OnAudioFocusChangeListener focusListener =
            new AudioManager.OnAudioFocusChangeListener() {
                public void onAudioFocusChange(int focusChange) {
                    // 通話は継続する(他アプリの音声要求には従わない)
                }
            };

    // --- その他 ---
    private WifiManager.WifiLock standbyWifiLock;
    private WifiManager.WifiLock callWifiLock;
    private PowerManager.WakeLock cpuLock;
    private Ringtone ringtone;
    private Vibrator vibrator;

    // ------------------------------------------------------------------
    // Service lifecycle
    // ------------------------------------------------------------------

    @Override
    public void onCreate() {
        super.onCreate();
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        createChannels();
        // startForegroundService() の後、数秒以内に前面サービスにする必要がある
        if (!startFg(false)) {
            stopSelf();
            return;
        }

        acquireStandbyWifiLock();

        alive = true;
        recvThread = new Thread(new Runnable() {
            public void run() {
                recvLoop();
            }
        }, "wifivoice-recv");
        recvThread.start();

        netExec.execute(new Runnable() {
            public void run() {
                openSocket();
            }
        });
        registerNetworkMonitoring();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // startForegroundService() で呼ばれるたびに前面サービスの宣言が必要
        startFg(state == IN_CALL);
        if (intent != null && ACTION_HANGUP.equals(intent.getAction())) {
            hangUp();
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onDestroy() {
        destroying = true;
        hangUp();
        if (netCallback != null) {
            try {
                cm.unregisterNetworkCallback(netCallback);
            } catch (RuntimeException e) {
                // ignore
            }
            netCallback = null;
        }
        if (cm != null) {
            try {
                cm.bindProcessToNetwork(null);
            } catch (RuntimeException e) {
                // ignore
            }
        }
        // 送信待ちのBYE等を出し切ってからソケットを閉じる
        netExec.shutdown();
        try {
            netExec.awaitTermination(1500, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        alive = false;
        DatagramSocket s = socket;
        socket = null;
        if (s != null) {
            s.close();
        }
        if (recvThread != null) {
            try {
                recvThread.join(1500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        handler.removeCallbacksAndMessages(null);
        if (standbyWifiLock != null && standbyWifiLock.isHeld()) {
            standbyWifiLock.release();
        }
        if (nm != null) {
            nm.cancel(NOTIF_INCOMING);
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------
    // UIから呼ぶAPI (メインスレッド)
    // ------------------------------------------------------------------

    public void setListener(Listener l) {
        listener = l;
    }

    public int getState() {
        return state;
    }

    public String getPeerAddress() {
        InetAddress p = peer;
        return p == null ? "" : p.getHostAddress();
    }

    public String getOwnIp() {
        return ownIp;
    }

    public boolean isRemoteRinging() {
        return remoteRinging;
    }

    public long getConnectedAt() {
        return connectedAt;
    }

    public boolean isSpeakerOn() {
        return speakerOn;
    }

    /** スピーカー通話の切り替え。音声は作り直さず、出力先だけを切り替える */
    public void setSpeaker(boolean on) {
        speakerOn = on;
        if (audioOn) {
            applySpeaker(on);
        }
        notifyState();
    }

    /** 発信 */
    public void call(String ip) {
        if (state != IDLE) {
            return;
        }
        if (!hasMic()) {
            message("マイクの許可が必要です");
            return;
        }
        InetAddress addr;
        try {
            // 数値のIPv4をバイト列に直接変換する (名前解決=ネットワーク処理を避ける)
            String[] parts = ip.split("\\.");
            if (parts.length != 4) {
                throw new IllegalArgumentException("not ipv4");
            }
            byte[] raw = new byte[4];
            for (int i = 0; i < 4; i++) {
                int v = Integer.parseInt(parts[i]);
                if (v < 0 || v > 255) {
                    throw new IllegalArgumentException("octet");
                }
                raw[i] = (byte) v;
            }
            addr = InetAddress.getByAddress(raw);
        } catch (Exception e) {
            message("相手のIPアドレスが不正です");
            return;
        }
        peer = addr;
        remoteRinging = false;
        callStart = SystemClock.elapsedRealtime();
        setState(CALLING);
        ensureTick();
        // 最初のINVITEが送れなければ(Wi-Fi未接続など)すぐに通知して終了する
        sendAsync(addr, T_INVITE, 1, true);
    }

    /** 着信に応答 */
    public void accept() {
        if (state != RINGING) {
            return;
        }
        stopRinging();
        nm.cancel(NOTIF_INCOMING);
        if (!hasMic()) {
            sendBurst(peer, T_REJECT);
            endCall("マイクの許可がないため応答できませんでした");
            return;
        }
        sendTo(peer, T_ACCEPT);
        if (!enterCall()) {
            sendBurst(peer, T_BYE);
            endCall("マイクを使用できません");
        }
    }

    /** 状況に応じて 発信取消 / 着信拒否 / 通話切断 */
    public void hangUp() {
        switch (state) {
            case CALLING:
            case IN_CALL:
                sendBurst(peer, T_BYE);
                break;
            case RINGING:
                sendBurst(peer, T_REJECT);
                break;
            default:
                return;
        }
        endCall(null);
    }

    // ------------------------------------------------------------------
    // 状態管理 (メインスレッド)
    // ------------------------------------------------------------------

    private void setState(int s) {
        state = s;
        notifyState();
    }

    private void notifyState() {
        if (listener != null) {
            listener.onStateChanged();
        }
    }

    private void message(String msg) {
        if (listener != null) {
            listener.onMessage(msg);
        } else {
            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
        }
    }

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean enterCall() {
        connectedAt = SystemClock.elapsedRealtime();
        // マイク型の前面サービスにする(画面を閉じた後も録音を続けるために必要)
        startFg(true);
        if (!startAudio()) {
            startFg(false);
            return false;
        }
        lastVoice = connectedAt;
        remoteRinging = false;

        if (cpuLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wifivoice:call");
            cpuLock.setReferenceCounted(false);
        }
        if (!cpuLock.isHeld()) {
            cpuLock.acquire();
        }
        acquireCallWifiLock();

        setState(IN_CALL);
        ensureTick();
        return true;
    }

    private void endCall(String msg) {
        handler.removeCallbacks(tick);
        stopRinging();
        stopAudio();
        speakerOn = false;
        if (cpuLock != null && cpuLock.isHeld()) {
            cpuLock.release();
        }
        if (callWifiLock != null && callWifiLock.isHeld()) {
            callWifiLock.release();
        }
        nm.cancel(NOTIF_INCOMING);
        peer = null;
        remoteRinging = false;
        boolean wasInCall = state == IN_CALL;
        setState(IDLE);
        if (!destroying) {
            startFg(false); // 待受の通知・サービス種別に戻す
        }
        if (msg != null) {
            message(msg);
        }
        if (wasInCall && !destroying) {
            nm.cancel(NOTIF_INCOMING);
        }
    }

    /** 着信中に相手が切った / 呼び出しが途絶えた場合 */
    private void endRingingAsMissed() {
        String who = displayName(peer);
        endCall(null);
        postMissed(who);
        message("不在着信: " + who);
    }

    private void ensureTick() {
        handler.removeCallbacks(tick);
        handler.postDelayed(tick, 1000);
    }

    /** 1秒ごとの見張り: INVITE再送 / 応答なし / 不在着信 / 通話途切れ / 着信音の再生継続 */
    private final Runnable tick = new Runnable() {
        public void run() {
            long now = SystemClock.elapsedRealtime();
            if (state == CALLING) {
                if (now - callStart > CALL_TIMEOUT) {
                    sendBurst(peer, T_BYE);
                    endCall("応答がありません");
                    return;
                }
                sendTo(peer, T_INVITE); // UDPなので再送して取りこぼしを防ぐ
            } else if (state == RINGING) {
                if (now - lastInvite > RING_TIMEOUT) {
                    endRingingAsMissed();
                    return;
                }
                if (ringtone != null && !ringtone.isPlaying()) {
                    ringtone.play(); // 古いOSではループ指定がないので再生を続ける
                }
            } else if (state == IN_CALL) {
                if (now - lastVoice > VOICE_TIMEOUT) {
                    sendBurst(peer, T_BYE);
                    endCall("通信が途切れました");
                    return;
                }
            }
            if (state != IDLE) {
                handler.postDelayed(this, 1000);
            }
        }
    };

    /** 受信した制御パケットの処理 */
    private void onControl(int type, InetAddress from) {
        switch (type) {
            case T_INVITE:
                handleInvite(from);
                break;
            case T_RINGING:
                if (state == CALLING && from.equals(peer)) {
                    remoteRinging = true;
                    notifyState();
                }
                break;
            case T_ACCEPT:
                if (state == CALLING && from.equals(peer)) {
                    if (!enterCall()) {
                        sendBurst(peer, T_BYE);
                        endCall("マイクを使用できません");
                    }
                }
                break;
            case T_REJECT:
                if (state == CALLING && from.equals(peer)) {
                    endCall("相手が通話を拒否しました");
                }
                break;
            case T_BUSY:
                if (state == CALLING && from.equals(peer)) {
                    endCall("相手は通話中です");
                }
                break;
            case T_BYE:
                if (from.equals(peer)) {
                    if (state == IN_CALL) {
                        endCall("通話が終了しました");
                    } else if (state == RINGING) {
                        endRingingAsMissed();
                    }
                }
                break;
            default:
                break;
        }
    }

    private void handleInvite(InetAddress from) {
        long now = SystemClock.elapsedRealtime();
        if (state == IDLE) {
            peer = from;
            lastInvite = now;
            sendTo(from, T_RINGING);
            setState(RINGING);
            startRinging();
            showIncomingNotification();
            ensureTick();
        } else if (from.equals(peer)) {
            if (state == RINGING) {
                lastInvite = now;
                sendTo(from, T_RINGING);
            } else if (state == IN_CALL) {
                sendTo(from, T_ACCEPT); // ACCEPTが届いていなかった場合の再送
            } else if (state == CALLING) {
                // お互いに同時に発信した場合はそのままつなぐ
                sendTo(from, T_ACCEPT);
                if (!enterCall()) {
                    sendBurst(peer, T_BYE);
                    endCall("マイクを使用できません");
                }
            }
        } else {
            sendTo(from, T_BUSY);
        }
    }

    // ------------------------------------------------------------------
    // 前面サービスと通知
    // ------------------------------------------------------------------

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        NotificationChannel standby = new NotificationChannel(
                CH_STANDBY, "待受", NotificationManager.IMPORTANCE_LOW);
        standby.setShowBadge(false);
        nm.createNotificationChannel(standby);

        // 着信音は自前で鳴らす(応答/拒否で確実に止めるため)ので、チャンネル自体は無音
        NotificationChannel incoming = new NotificationChannel(
                CH_INCOMING, "着信", NotificationManager.IMPORTANCE_HIGH);
        incoming.setSound(null, null);
        incoming.enableVibration(false);
        incoming.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(incoming);

        NotificationChannel missed = new NotificationChannel(
                CH_MISSED, "不在着信", NotificationManager.IMPORTANCE_DEFAULT);
        nm.createNotificationChannel(missed);
    }

    /**
     * 前面サービスにする。種別:
     *  - 待受: specialUse (Android 14+)。それ以前は種別なし
     *  - 通話中: specialUse + microphone (Android 14+) / microphone (Android 11-13)
     * 失敗したら false(待受の通知の更新のみ失敗した場合は true を返す)。
     */
    private boolean startFg(boolean inCall) {
        Notification n = inCall ? buildCallNotification() : buildStandbyNotification();
        int type = 0;
        if (Build.VERSION.SDK_INT >= 34) {
            type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
            if (inCall) {
                type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            }
        } else if (Build.VERSION.SDK_INT >= 30 && inCall) {
            type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_FG, n, type);
            } else {
                startForeground(NOTIF_FG, n);
            }
            return true;
        } catch (RuntimeException e) {
            if (inCall) {
                // マイク型が許可されなかった場合は、待受の種別でそのまま続ける
                return startFg(false);
            }
            return false;
        }
    }

    private void refreshStandbyNotification() {
        if (state == IDLE && nm != null) {
            nm.notify(NOTIF_FG, buildStandbyNotification());
        }
    }

    private Notification.Builder newBuilder(String channel) {
        if (Build.VERSION.SDK_INT >= 26) {
            return new Notification.Builder(this, channel);
        }
        return new Notification.Builder(this);
    }

    private PendingIntent openApp(String action, int requestCode) {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (action != null) {
            i.setAction(action);
        }
        return PendingIntent.getActivity(this, requestCode, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private PendingIntent serviceAction(String action, int requestCode) {
        Intent i = new Intent(this, CallService.class).setAction(action);
        return PendingIntent.getService(this, requestCode, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification buildStandbyNotification() {
        String ip = ownIp;
        Notification.Builder b = newBuilder(CH_STANDBY)
                .setSmallIcon(android.R.drawable.sym_action_call)
                .setContentTitle("WiFi音声通話  待受中")
                .setContentText(ip == null ? "Wi-Fi未接続" : "自分のIP " + ip)
                .setOngoing(true)
                .setShowWhen(false)
                .setContentIntent(openApp(null, 10));
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_LOW);
        }
        return b.build();
    }

    private Notification buildCallNotification() {
        Notification.Builder b = newBuilder(CH_STANDBY)
                .setSmallIcon(android.R.drawable.sym_action_call)
                .setContentTitle("通話中")
                .setContentText(displayName(peer))
                .setOngoing(true)
                .setShowWhen(true)
                .setUsesChronometer(true)
                .setWhen(System.currentTimeMillis())
                .setContentIntent(openApp(null, 10))
                .addAction(0, "切断", serviceAction(ACTION_HANGUP, 12));
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_LOW);
        }
        return b.build();
    }

    /** 着信通知: フルスクリーンインテントで画面を出す。操作できる場合は応答/拒否ボタンも付く */
    private void showIncomingNotification() {
        PendingIntent open = openApp(null, 10);
        Notification.Builder b = newBuilder(CH_INCOMING)
                .setSmallIcon(android.R.drawable.sym_call_incoming)
                .setContentTitle("着信")
                .setContentText(displayName(peer))
                .setCategory(Notification.CATEGORY_CALL)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentIntent(open)
                .setFullScreenIntent(open, true)
                // 応答は画面を開いてから行う(通知から直接マイクを開始できない場合があるため)
                .addAction(0, "拒否", serviceAction(ACTION_HANGUP, 12))
                .addAction(0, "応答", openApp(ACTION_ANSWER, 11));
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_HIGH);
        }
        nm.notify(NOTIF_INCOMING, b.build());
    }

    private void postMissed(String who) {
        Notification.Builder b = newBuilder(CH_MISSED)
                .setSmallIcon(android.R.drawable.sym_call_missed)
                .setContentTitle("不在着信")
                .setContentText(who)
                .setAutoCancel(true)
                .setContentIntent(openApp(null, 10));
        nm.notify(NOTIF_MISSED, b.build());
    }

    private String displayName(InetAddress a) {
        if (a == null) {
            return "";
        }
        String ip = a.getHostAddress();
        String name = Contacts.nameFor(this, ip);
        return name == null ? ip : name + " (" + ip + ")";
    }

    // ------------------------------------------------------------------
    // 着信音・バイブ
    // ------------------------------------------------------------------

    @SuppressWarnings("deprecation")
    private void startRinging() {
        int mode = am.getRingerMode();
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        if (mode == AudioManager.RINGER_MODE_NORMAL) {
            try {
                Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
                ringtone = RingtoneManager.getRingtone(this, uri);
                if (ringtone != null) {
                    ringtone.setAudioAttributes(attrs);
                    if (Build.VERSION.SDK_INT >= 28) {
                        ringtone.setLooping(true);
                    }
                    ringtone.play();
                }
            } catch (RuntimeException e) {
                ringtone = null;
            }
        }
        if (mode != AudioManager.RINGER_MODE_SILENT) {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                long[] pattern = new long[] { 0, 800, 800 };
                try {
                    if (Build.VERSION.SDK_INT >= 26) {
                        vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0), attrs);
                    } else {
                        vibrator.vibrate(pattern, 0, attrs);
                    }
                } catch (RuntimeException e) {
                    // ignore
                }
            }
        }
    }

    private void stopRinging() {
        if (ringtone != null) {
            try {
                ringtone.stop();
            } catch (RuntimeException e) {
                // ignore
            }
            ringtone = null;
        }
        if (vibrator != null) {
            vibrator.cancel();
            vibrator = null;
        }
    }

    // ------------------------------------------------------------------
    // Wi-Fi / ネットワーク
    // ------------------------------------------------------------------

    @SuppressWarnings("deprecation")
    private void acquireStandbyWifiLock() {
        if (wifi == null) {
            return;
        }
        try {
            standbyWifiLock = wifi.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "wifivoice:standby");
            standbyWifiLock.setReferenceCounted(false);
            standbyWifiLock.acquire();
        } catch (RuntimeException e) {
            standbyWifiLock = null;
        }
    }

    private void acquireCallWifiLock() {
        if (wifi == null || Build.VERSION.SDK_INT < 29) {
            return;
        }
        try {
            if (callWifiLock == null) {
                callWifiLock = wifi.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "wifivoice:call");
                callWifiLock.setReferenceCounted(false);
            }
            if (!callWifiLock.isHeld()) {
                callWifiLock.acquire();
            }
        } catch (RuntimeException e) {
            callWifiLock = null;
        }
    }

    /**
     * Wi-Fiのネットワークを監視し、プロセスをそのネットワークに結び付ける。
     * (Wi-Fiにインターネットがない場合などにOSが通信をモバイル回線へ回しても、
     *  同じWi-Fi内の相手との通信が通るようにするため)
     */
    private void registerNetworkMonitoring() {
        NetworkRequest request = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build();
        netCallback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(final Network network) {
                handler.post(new Runnable() {
                    public void run() {
                        onWifiAvailable(network);
                    }
                });
            }

            @Override
            public void onLost(final Network network) {
                handler.post(new Runnable() {
                    public void run() {
                        onWifiLost(network);
                    }
                });
            }

            @Override
            public void onLinkPropertiesChanged(final Network network, final LinkProperties lp) {
                handler.post(new Runnable() {
                    public void run() {
                        onWifiLink(network, lp);
                    }
                });
            }
        };
        try {
            cm.registerNetworkCallback(request, netCallback);
        } catch (RuntimeException e) {
            netCallback = null;
        }
    }

    private void onWifiAvailable(Network network) {
        wifiNetwork = network;
        try {
            cm.bindProcessToNetwork(network);
        } catch (RuntimeException e) {
            // ignore
        }
        // 新しいネットワークに結び付けた状態でソケットを作り直す
        netExec.execute(new Runnable() {
            public void run() {
                openSocket();
            }
        });
    }

    private void onWifiLost(Network network) {
        if (wifiNetwork == null || !wifiNetwork.equals(network)) {
            return;
        }
        wifiNetwork = null;
        ownIp = null;
        try {
            cm.bindProcessToNetwork(null);
        } catch (RuntimeException e) {
            // ignore
        }
        if (state != IDLE) {
            endCall("Wi-Fiが切断されました");
        }
        refreshStandbyNotification();
        notifyState();
    }

    private void onWifiLink(Network network, LinkProperties lp) {
        if (wifiNetwork == null) {
            wifiNetwork = network;
        }
        if (!wifiNetwork.equals(network)) {
            return;
        }
        String found = null;
        for (LinkAddress la : lp.getLinkAddresses()) {
            InetAddress a = la.getAddress();
            if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                found = a.getHostAddress();
                break;
            }
        }
        if (found != null && !found.equals(ownIp)) {
            ownIp = found;
            refreshStandbyNotification();
            notifyState();
        }
    }

    // ------------------------------------------------------------------
    // ソケット (netExec / 受信スレッドのみで使用)
    // ------------------------------------------------------------------

    private void openSocket() {
        DatagramSocket old = socket;
        socket = null;
        if (old != null) {
            old.close();
        }
        if (!alive) {
            return;
        }
        try {
            DatagramSocket s = new DatagramSocket(null);
            s.setReuseAddress(true);
            s.bind(new InetSocketAddress(PORT));
            s.setSoTimeout(1000);
            socket = s;
        } catch (final IOException e) {
            handler.post(new Runnable() {
                public void run() {
                    message("待受を開始できません: " + e.getMessage());
                }
            });
        }
    }

    /** 制御パケットを1回送る (非同期) */
    private void sendTo(InetAddress to, int type) {
        sendAsync(to, type, 1, false);
    }

    /** 切断系は取りこぼし対策で3回送る (非同期) */
    private void sendBurst(InetAddress to, int type) {
        sendAsync(to, type, 3, false);
    }

    /**
     * 送信専用スレッドで制御パケットを送る。
     * reportFail が true で送信に失敗した場合は、発信中ならその通話を終了して通知する。
     */
    private void sendAsync(final InetAddress to, final int type, final int times,
            final boolean reportFail) {
        if (to == null) {
            return;
        }
        try {
            netExec.execute(new Runnable() {
                public void run() {
                    boolean ok = true;
                    for (int i = 0; i < times; i++) {
                        if (!doSend(to, type)) {
                            ok = false;
                        }
                    }
                    if (!ok && reportFail) {
                        handler.post(new Runnable() {
                            public void run() {
                                if (state == CALLING && to.equals(peer)) {
                                    endCall("送信できません。Wi-Fi接続を確認してください");
                                }
                            }
                        });
                    }
                }
            });
        } catch (RejectedExecutionException e) {
            // サービス終了処理中は送らない
        }
    }

    private boolean doSend(InetAddress to, int type) {
        DatagramSocket s = socket;
        if (s == null) {
            return false;
        }
        byte[] b = new byte[] { MAGIC, (byte) type };
        try {
            s.send(new DatagramPacket(b, b.length, to, PORT));
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private static void sleepQuietly(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void recvLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        byte[] buf = new byte[1024];
        DatagramPacket p = new DatagramPacket(buf, buf.length);
        while (alive) {
            DatagramSocket s = socket;
            if (s == null) {
                sleepQuietly(200); // Wi-Fi切り替え中など
                continue;
            }
            try {
                p.setLength(buf.length);
                s.receive(p);
            } catch (SocketTimeoutException e) {
                continue;
            } catch (IOException e) {
                sleepQuietly(100); // 閉じられた / 切り替え中。次のループで新しいソケットを取得
                continue;
            }
            int len = p.getLength();
            if (len < HEADER || buf[0] != MAGIC) {
                continue;
            }
            final int type = buf[1];
            final InetAddress from = p.getAddress();
            if (type == T_VOICE) {
                if (audioOn && from.equals(peer)) {
                    lastVoice = SystemClock.elapsedRealtime();
                    int n = (len - HEADER) & ~1;
                    synchronized (audioLock) {
                        AudioTrack t = track;
                        if (t != null && n > 0) {
                            try {
                                t.write(buf, HEADER, n);
                            } catch (RuntimeException e) {
                                // 停止処理と競合した場合は無視
                            }
                        }
                    }
                }
            } else {
                handler.post(new Runnable() {
                    public void run() {
                        onControl(type, from);
                    }
                });
            }
        }
    }

    // ------------------------------------------------------------------
    // 音声 (8kHz / モノラル / 16bit。通話用の設定)
    // ------------------------------------------------------------------

    private boolean startAudio() {
        try {
            int recMin = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int trMin = AudioTrack.getMinBufferSize(SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (recMin <= 0 || trMin <= 0) {
                return false;
            }

            // 通話モード + オーディオフォーカス
            am.setMode(AudioManager.MODE_IN_COMMUNICATION);
            requestFocus();

            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build();

            AudioRecord rec = new AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                    .setAudioFormat(new AudioFormat.Builder()
                            .setSampleRate(SAMPLE_RATE)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                            .build())
                    .setBufferSizeInBytes(Math.max(recMin, FRAME_BYTES * 4))
                    .build();
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
                rec.release();
                abandonFocus();
                am.setMode(AudioManager.MODE_NORMAL);
                return false;
            }

            AudioTrack tr = new AudioTrack.Builder()
                    .setAudioAttributes(attrs)
                    .setAudioFormat(new AudioFormat.Builder()
                            .setSampleRate(SAMPLE_RATE)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build())
                    .setBufferSizeInBytes(Math.max(trMin * 2, FRAME_BYTES * 8))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            if (tr.getState() != AudioTrack.STATE_INITIALIZED) {
                rec.release();
                tr.release();
                abandonFocus();
                am.setMode(AudioManager.MODE_NORMAL);
                return false;
            }

            // 端末が対応していればエコー除去・雑音抑制を有効にする
            try {
                if (AcousticEchoCanceler.isAvailable()) {
                    aec = AcousticEchoCanceler.create(rec.getAudioSessionId());
                    if (aec != null) {
                        aec.setEnabled(true);
                    }
                }
                if (NoiseSuppressor.isAvailable()) {
                    ns = NoiseSuppressor.create(rec.getAudioSessionId());
                    if (ns != null) {
                        ns.setEnabled(true);
                    }
                }
            } catch (RuntimeException e) {
                // 効果なしで続ける
            }

            recorder = rec;
            synchronized (audioLock) {
                track = tr;
            }
            tr.play();
            audioOn = true;
            applySpeaker(speakerOn);

            final AudioRecord r = rec;
            sendThread = new Thread(new Runnable() {
                public void run() {
                    sendLoop(r);
                }
            }, "wifivoice-send");
            sendThread.start();
            return true;
        } catch (RuntimeException e) {
            stopAudio();
            return false;
        }
    }

    private void stopAudio() {
        boolean wasOn = audioOn;
        audioOn = false;
        if (sendThread != null) {
            try {
                sendThread.join(1500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            sendThread = null;
        }
        if (aec != null) {
            aec.release();
            aec = null;
        }
        if (ns != null) {
            ns.release();
            ns = null;
        }
        if (recorder != null) {
            try {
                if (recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) {
                    recorder.stop();
                }
            } catch (RuntimeException e) {
                // ignore
            }
            recorder.release();
            recorder = null;
        }
        synchronized (audioLock) {
            if (track != null) {
                try {
                    track.stop();
                } catch (RuntimeException e) {
                    // ignore
                }
                track.release();
                track = null;
            }
        }
        if (wasOn || am.getMode() == AudioManager.MODE_IN_COMMUNICATION) {
            applySpeaker(false);
            abandonFocus();
            am.setMode(AudioManager.MODE_NORMAL);
        }
    }

    /** 出力先の切り替え。Android 12+ は通信デバイス指定、それ以前はスピーカーフォン */
    @SuppressWarnings("deprecation")
    private void applySpeaker(boolean on) {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                if (on) {
                    for (AudioDeviceInfo d : am.getAvailableCommunicationDevices()) {
                        if (d.getType() == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) {
                            am.setCommunicationDevice(d);
                            return;
                        }
                    }
                } else {
                    am.clearCommunicationDevice();
                }
            } else {
                am.setSpeakerphoneOn(on);
            }
        } catch (RuntimeException e) {
            // ignore
        }
    }

    @SuppressWarnings("deprecation")
    private void requestFocus() {
        if (Build.VERSION.SDK_INT >= 26) {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build();
            focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                    .setAudioAttributes(attrs)
                    .setOnAudioFocusChangeListener(focusListener)
                    .build();
            am.requestAudioFocus(focusRequest);
        } else {
            am.requestAudioFocus(focusListener, AudioManager.STREAM_VOICE_CALL,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
        }
    }

    @SuppressWarnings("deprecation")
    private void abandonFocus() {
        if (Build.VERSION.SDK_INT >= 26) {
            if (focusRequest != null) {
                am.abandonAudioFocusRequest(focusRequest);
                focusRequest = null;
            }
        } else {
            am.abandonAudioFocus(focusListener);
        }
    }

    /** マイク → UDP送信 */
    private void sendLoop(AudioRecord rec) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
        byte[] buf = new byte[HEADER + FRAME_BYTES];
        buf[0] = MAGIC;
        buf[1] = (byte) T_VOICE;
        try {
            rec.startRecording();
            while (audioOn) {
                int filled = 0;
                while (audioOn && filled < FRAME_BYTES) {
                    int n = rec.read(buf, HEADER + filled, FRAME_BYTES - filled);
                    if (n < 0) {
                        return;
                    }
                    filled += n;
                }
                InetAddress to = peer;
                DatagramSocket s = socket;
                if (!audioOn || to == null) {
                    break;
                }
                if (s == null) {
                    continue; // Wi-Fi切り替え中
                }
                try {
                    s.send(new DatagramPacket(buf, buf.length, to, PORT));
                } catch (IOException e) {
                    // 一時的な送信失敗は無視 (途切れが続けば見張りが切断する)
                }
            }
        } catch (RuntimeException e) {
            // 録音停止との競合
        }
    }
}
