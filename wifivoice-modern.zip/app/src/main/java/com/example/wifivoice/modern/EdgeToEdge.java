package com.example.wifivoice.modern;

import android.view.View;
import android.view.WindowInsets;

/**
 * targetSdk 35 (Android 15+) では画面が常にエッジ・ツー・エッジ(システムバーの下まで描画)になるため、
 * ステータスバー/ナビゲーションバー/切り欠きの分だけ余白を足して内容が隠れないようにする。
 */
final class EdgeToEdge {

    private EdgeToEdge() {
    }

    @SuppressWarnings("deprecation")
    static void apply(View root, final int basePx) {
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                v.setPadding(basePx + insets.getSystemWindowInsetLeft(),
                        basePx + insets.getSystemWindowInsetTop(),
                        basePx + insets.getSystemWindowInsetRight(),
                        basePx + insets.getSystemWindowInsetBottom());
                return insets;
            }
        });
        root.requestApplyInsets();
    }
}
