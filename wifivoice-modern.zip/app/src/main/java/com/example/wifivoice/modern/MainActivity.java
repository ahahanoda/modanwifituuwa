package com.example.wifivoice.modern;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 電話風UI。発信ダイヤル / 発信中 / 着信 / 通話中 を1画面で切り替える。
 * ランタイム権限(マイク・通知)の要求と、待受サービスの起動を行う。
 */
public class MainActivity extends Activity implements CallService.Listener {

    private static final String PREFS = "wifivoice";
    private static final String KEY_IP = "peer_ip";
    private static final String KEY_STANDBY = "standby";
    private static final int MAX_LEN = 15;
    private static final int REQ_CONTACT = 1;
    private static final int REQ_PERM = 10;
    private static final String DEL = "削除";
    private static final Pattern IPV4 =
            Pattern.compile("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$");

    private TextView tvStatus;
    private TextView tvNumber;
    private View panelDial;
    private View panelCall;
    private Button btnAccept;
    private Button btnHangUp;
    private Button btnSpeaker;

    private final StringBuilder dial = new StringBuilder();
    private final Handler handler = new Handler();
    private CallService service;
    private boolean bound;

    /** マイク許可の結果待ちで保留している操作 */
    private boolean pendingDial;
    private boolean pendingAccept;
    /** 通知の「応答」から開かれた場合 */
    private boolean answerRequested;

    private final Runnable ticker = new Runnable() {
        public void run() {
            render();
            handler.postDelayed(this, 1000);
        }
    };

    private final ServiceConnection connection = new ServiceConnection() {
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = ((CallService.LocalBinder) binder).getService();
            service.setListener(MainActivity.this);
            render();
            processAnswerRequest();
        }

        public void onServiceDisconnected(ComponentName name) {
            service = null;
            render();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 着信時にロック画面の上に出し、画面を点灯する
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        setContentView(R.layout.main);
        EdgeToEdge.apply(findViewById(R.id.root), dp(8));
        setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);

        tvStatus = (TextView) findViewById(R.id.tv_status);
        tvNumber = (TextView) findViewById(R.id.tv_number);
        panelDial = findViewById(R.id.panel_dial);
        panelCall = findViewById(R.id.panel_call);
        btnAccept = (Button) findViewById(R.id.btn_accept);
        btnHangUp = (Button) findViewById(R.id.btn_hangup);
        btnSpeaker = (Button) findViewById(R.id.btn_speaker);

        buildKeypad();

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String last = prefs.getString(KEY_IP, "");
        dial.append(last.length() > 0 ? last : "192.168.");

        startStandby();
        requestNeededPermissions();
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent != null && CallService.ACTION_ANSWER.equals(intent.getAction())) {
            answerRequested = true;
            intent.setAction(null); // 向きを変えた時などに再実行しない
            processAnswerRequest();
        }
    }

    private void processAnswerRequest() {
        if (!answerRequested || service == null) {
            return;
        }
        answerRequested = false;
        if (service.getState() == CallService.RINGING) {
            onAccept(null);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        bound = bindService(new Intent(this, CallService.class), connection, 0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (service != null) {
            service.setListener(null);
            service = null;
        }
        if (bound) {
            unbindService(connection);
            bound = false;
        }
        super.onStop();
    }

    // ------------------------------------------------------------------
    // 待受サービス / 権限
    // ------------------------------------------------------------------

    /** 待受(前面サービス)を開始。画面が見えている間に開始するのでOSの制限に掛からない */
    private void startStandby() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_STANDBY, true).apply();
        Intent i = new Intent(this, CallService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(i);
            } else {
                startService(i);
            }
        } catch (RuntimeException e) {
            Toast.makeText(this, "待受を開始できません", Toast.LENGTH_LONG).show();
        }
    }

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasNotificationPermission() {
        return Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestNeededPermissions() {
        List<String> need = new ArrayList<String>();
        if (!hasMic()) {
            need.add(Manifest.permission.RECORD_AUDIO);
        }
        if (!hasNotificationPermission()) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), REQ_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERM) {
            return;
        }
        if (hasMic()) {
            if (pendingDial) {
                pendingDial = false;
                onDial(null);
            }
            if (pendingAccept) {
                pendingAccept = false;
                onAccept(null);
            }
        } else {
            pendingDial = false;
            pendingAccept = false;
            if (!shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                // 「今後表示しない」相当 → 設定画面から許可してもらう
                new AlertDialog.Builder(this)
                        .setMessage("通話にはマイクの許可が必要です。設定画面で許可してください。")
                        .setPositiveButton("設定を開く", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                openAppDetails();
                            }
                        })
                        .setNegativeButton("キャンセル", null)
                        .show();
            } else {
                Toast.makeText(this, "マイクの許可が必要です", Toast.LENGTH_SHORT).show();
            }
        }
        render();
    }

    private void openAppDetails() {
        startActivitySafely(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName())));
    }

    private void startActivitySafely(Intent i) {
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "この端末では開けませんでした", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_CONTACT && resultCode == RESULT_OK && data != null) {
            String ip = data.getStringExtra(ContactsActivity.EXTRA_IP);
            if (ip != null) {
                dial.setLength(0);
                dial.append(ip);
                render();
            }
        }
    }

    // --- Listener ---
    public void onStateChanged() {
        render();
    }

    public void onMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------
    // ボタン (layoutのandroid:onClick)
    // ------------------------------------------------------------------

    public void onDial(View v) {
        String ip = dial.toString().trim();
        if (!isValidIpv4(ip)) {
            Toast.makeText(this, "IPアドレスの形式が正しくありません", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!hasMic()) {
            pendingDial = true;
            requestPermissions(new String[] { Manifest.permission.RECORD_AUDIO }, REQ_PERM);
            return;
        }
        if (service == null) {
            Toast.makeText(this, "準備中です。もう一度押してください", Toast.LENGTH_SHORT).show();
            return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_IP, ip).apply();
        service.call(ip);
    }

    public void onAccept(View v) {
        if (service == null) {
            return;
        }
        if (!hasMic()) {
            pendingAccept = true;
            requestPermissions(new String[] { Manifest.permission.RECORD_AUDIO }, REQ_PERM);
            return;
        }
        service.accept();
    }

    public void onHangUp(View v) {
        if (service != null) {
            service.hangUp();
        }
    }

    public void onSpeaker(View v) {
        if (service != null) {
            service.setSpeaker(!service.isSpeakerOn());
        }
    }

    public void onContacts(View v) {
        startActivityForResult(new Intent(this, ContactsActivity.class), REQ_CONTACT);
    }

    /** 入力中のIPを連絡先に登録 */
    public void onSaveContact(View v) {
        final String ip = dial.toString().trim();
        if (!isValidIpv4(ip)) {
            Toast.makeText(this, "IPアドレスの形式が正しくありません", Toast.LENGTH_SHORT).show();
            return;
        }
        final EditText nameEdit = new EditText(this);
        nameEdit.setSingleLine(true);
        nameEdit.setHint("名前");
        String existing = Contacts.nameFor(this, ip);
        if (existing != null) {
            nameEdit.setText(existing);
        }
        new AlertDialog.Builder(this)
                .setTitle("連絡先に登録 (" + ip + ")")
                .setView(nameEdit)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String name = nameEdit.getText().toString().trim();
                        if (name.length() == 0) {
                            Toast.makeText(MainActivity.this, "名前を入力してください",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Contacts.save(MainActivity.this, name, ip);
                        Toast.makeText(MainActivity.this, "登録しました", Toast.LENGTH_SHORT).show();
                        render();
                    }
                })
                .setNegativeButton("キャンセル", null)
                .show();
    }

    /** 設定メニュー(最近の端末にはメニューキーがないので画面上のボタンから開く) */
    public void onSettings(View v) {
        final boolean ignoring = isIgnoringBatteryOptimizations();
        final String[] items = {
                "待受を終了",
                "電池の最適化: " + (ignoring ? "除外済み" : "対象 (タップで除外を依頼)"),
                "通知の設定" + (hasNotificationPermission() ? "" : " (未許可)"),
                "着信の全画面表示の許可",
                "アプリの権限設定" + (hasMic() ? "" : " (マイク未許可)")
        };
        new AlertDialog.Builder(this)
                .setTitle("設定")
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        onSettingsItem(which, ignoring);
                    }
                })
                .show();
    }

    private void onSettingsItem(int which, boolean ignoring) {
        switch (which) {
            case 0:
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putBoolean(KEY_STANDBY, false).apply();
                stopService(new Intent(this, CallService.class));
                Toast.makeText(this, "待受を終了しました", Toast.LENGTH_SHORT).show();
                finish();
                break;
            case 1:
                if (ignoring) {
                    Toast.makeText(this, "すでに除外されています", Toast.LENGTH_SHORT).show();
                } else {
                    startActivitySafely(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + getPackageName())));
                }
                break;
            case 2:
                if (Build.VERSION.SDK_INT >= 26) {
                    startActivitySafely(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
                } else {
                    openAppDetails();
                }
                break;
            case 3:
                openFullScreenIntentSettings();
                break;
            default:
                openAppDetails();
                break;
        }
    }

    private void openFullScreenIntentSettings() {
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm.canUseFullScreenIntent()) {
                Toast.makeText(this, "許可済みです", Toast.LENGTH_SHORT).show();
            } else {
                startActivitySafely(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + getPackageName())));
            }
        } else {
            Toast.makeText(this, "この端末では設定不要です", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isIgnoringBatteryOptimizations() {
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    // ------------------------------------------------------------------
    // 描画
    // ------------------------------------------------------------------

    private void render() {
        int state = service == null ? CallService.IDLE : service.getState();

        if (state == CallService.IDLE) {
            panelDial.setVisibility(View.VISIBLE);
            panelCall.setVisibility(View.GONE);
            findViewById(R.id.bar).setVisibility(View.VISIBLE);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            String ip = service == null ? null : service.getOwnIp();
            if (service == null) {
                tvStatus.setText("接続中…");
            } else {
                tvStatus.setText(ip == null ? "Wi-Fi未接続" : "待受中   自分のIP " + ip);
            }
            if (dial.length() == 0) {
                tvNumber.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
                tvNumber.setText("IPアドレスを入力");
                tvNumber.setTextColor(0xFF6B7785);
            } else {
                showNumber(dial.toString());
            }
            return;
        }

        panelDial.setVisibility(View.GONE);
        panelCall.setVisibility(View.VISIBLE);
        findViewById(R.id.bar).setVisibility(View.GONE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        showNumber(service.getPeerAddress());

        if (state == CallService.CALLING) {
            btnAccept.setVisibility(View.GONE);
            btnSpeaker.setVisibility(View.GONE);
            btnHangUp.setText("キャンセル");
            tvStatus.setText(service.isRemoteRinging() ? "呼び出し中…" : "発信中…");
        } else if (state == CallService.RINGING) {
            btnAccept.setVisibility(View.VISIBLE);
            btnSpeaker.setVisibility(View.GONE);
            btnHangUp.setText("拒否");
            tvStatus.setText("着信");
        } else {
            btnAccept.setVisibility(View.GONE);
            btnSpeaker.setVisibility(View.VISIBLE);
            boolean on = service.isSpeakerOn();
            btnSpeaker.setText(on ? "スピーカー: オン" : "スピーカー: オフ");
            btnSpeaker.setBackgroundResource(on ? R.drawable.bg_green : R.drawable.bg_key);
            btnHangUp.setText("切断");
            long sec = (SystemClock.elapsedRealtime() - service.getConnectedAt()) / 1000;
            if (sec < 0) {
                sec = 0;
            }
            tvStatus.setText("通話中   " + two(sec / 60) + ":" + two(sec % 60));
        }
    }

    /** 連絡先に登録済みなら「名前 + IP」、なければIPだけ表示 */
    private void showNumber(String ip) {
        String name = Contacts.nameFor(this, ip);
        tvNumber.setTextColor(Color.WHITE);
        if (name != null) {
            tvNumber.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
            tvNumber.setText(name + "\n" + ip);
        } else {
            tvNumber.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
            tvNumber.setText(ip);
        }
    }

    private static String two(long n) {
        return n < 10 ? "0" + n : String.valueOf(n);
    }

    // ------------------------------------------------------------------
    // キーパッド
    // ------------------------------------------------------------------

    private void buildKeypad() {
        LinearLayout keypad = (LinearLayout) findViewById(R.id.keypad);
        String[][] rows = {
                { "1", "2", "3" },
                { "4", "5", "6" },
                { "7", "8", "9" },
                { ".", "0", DEL } };
        int m = dp(4);
        for (int r = 0; r < rows.length; r++) {
            LinearLayout line = new LinearLayout(this);
            line.setOrientation(LinearLayout.HORIZONTAL);
            keypad.addView(line, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
            for (int c = 0; c < rows[r].length; c++) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
                lp.setMargins(m, m, m, m);
                line.addView(makeKey(rows[r][c]), lp);
            }
        }
    }

    private Button makeKey(final String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, DEL.equals(label) ? 18 : 26);
        b.setTextColor(Color.WHITE);
        b.setBackgroundResource(R.drawable.bg_key);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (DEL.equals(label)) {
                    if (dial.length() > 0) {
                        dial.deleteCharAt(dial.length() - 1);
                    }
                } else if (dial.length() < MAX_LEN) {
                    dial.append(label);
                }
                render();
            }
        });
        if (DEL.equals(label)) {
            b.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) {
                    dial.setLength(0);
                    render();
                    return true;
                }
            });
        }
        return b;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    public static boolean isValidIpv4(String s) {
        Matcher m = IPV4.matcher(s);
        if (!m.matches()) {
            return false;
        }
        for (int i = 1; i <= 4; i++) {
            if (Integer.parseInt(m.group(i)) > 255) {
                return false;
            }
        }
        return true;
    }
}
