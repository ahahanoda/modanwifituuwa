package com.example.wifivoice.modern;

import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.DigitsKeyListener;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

/** 連絡先一覧。タップで選択(MainActivityに戻る)、長押しで編集/削除、下のボタンで追加。 */
public class ContactsActivity extends Activity {

    public static final String EXTRA_IP = "ip";

    private ListView list;
    private List<Contacts.Item> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contacts);
        EdgeToEdge.apply(findViewById(R.id.root), dp(8));

        list = (ListView) findViewById(R.id.list);
        list.setEmptyView(findViewById(R.id.tv_empty));

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent result = new Intent();
                result.putExtra(EXTRA_IP, items.get(position).ip);
                setResult(RESULT_OK, result);
                finish();
            }
        });

        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                showActions(items.get(position));
                return true;
            }
        });

        findViewById(R.id.btn_add).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showEditDialog(null);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        items = Contacts.load(this);
        String[] labels = new String[items.size()];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = items.get(i).name + "\n" + items.get(i).ip;
        }
        list.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, labels));
    }

    private void showActions(final Contacts.Item item) {
        new AlertDialog.Builder(this)
                .setTitle(item.name)
                .setItems(new CharSequence[] { "編集", "削除" },
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                if (which == 0) {
                                    showEditDialog(item);
                                } else {
                                    confirmDelete(item);
                                }
                            }
                        })
                .show();
    }

    private void confirmDelete(final Contacts.Item item) {
        new AlertDialog.Builder(this)
                .setMessage(item.name + " を削除しますか?")
                .setPositiveButton("削除", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Contacts.remove(ContactsActivity.this, item.ip);
                        reload();
                    }
                })
                .setNegativeButton("キャンセル", null)
                .show();
    }

    /** old が null なら新規追加、そうでなければ編集 */
    private void showEditDialog(final Contacts.Item old) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        box.setPadding(pad, pad, pad, pad);

        final EditText nameEdit = new EditText(this);
        nameEdit.setHint("名前");
        nameEdit.setSingleLine(true);
        box.addView(nameEdit);

        final EditText ipEdit = new EditText(this);
        ipEdit.setHint("IPアドレス (例 192.168.1.5)");
        ipEdit.setSingleLine(true);
        ipEdit.setKeyListener(DigitsKeyListener.getInstance("0123456789."));
        box.addView(ipEdit);

        if (old != null) {
            nameEdit.setText(old.name);
            ipEdit.setText(old.ip);
        }

        new AlertDialog.Builder(this)
                .setTitle(old == null ? "連絡先を追加" : "連絡先を編集")
                .setView(box)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String name = nameEdit.getText().toString().trim();
                        String ip = ipEdit.getText().toString().trim();
                        if (name.length() == 0) {
                            toast("名前を入力してください");
                            return;
                        }
                        if (!MainActivity.isValidIpv4(ip)) {
                            toast("IPアドレスの形式が正しくありません");
                            return;
                        }
                        if (old != null && !old.ip.equals(ip)) {
                            Contacts.remove(ContactsActivity.this, old.ip);
                        }
                        Contacts.save(ContactsActivity.this, name, ip);
                        reload();
                    }
                })
                .setNegativeButton("キャンセル", null)
                .show();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
