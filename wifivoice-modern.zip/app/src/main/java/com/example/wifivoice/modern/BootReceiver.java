package com.example.wifivoice.modern;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

/**
 * 端末の起動後に待受(前面サービス)を再開する。
 * 起動時に開始できる前面サービスの種類には制限があるため、待受は specialUse 型のみで開始する
 * (マイク型は通話を始めるときに画面から切り替える)。
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("wifivoice", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("standby", true)) {
            return; // ユーザーが「待受を終了」した場合は再開しない
        }
        Intent service = new Intent(context, CallService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        } catch (RuntimeException e) {
            // OS側の制限で開始できない場合は、次にアプリを開いたときに再開する
        }
    }
}
