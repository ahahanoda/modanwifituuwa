package com.example.wifivoice.modern;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import android.content.Context;
import android.content.SharedPreferences;

/** 連絡先(名前 + IPアドレス)の保存。SharedPreferencesに1行1件で持つ。 */
public final class Contacts {

    private static final String PREFS = "wifivoice";
    private static final String KEY = "contacts";

    public static final class Item {
        public final String name;
        public final String ip;

        public Item(String name, String ip) {
            this.name = name;
            this.ip = ip;
        }
    }

    private Contacts() {
    }

    /** 名前順で返す */
    public static List<Item> load(Context c) {
        List<Item> list = new ArrayList<Item>();
        String raw = prefs(c).getString(KEY, "");
        if (raw.length() > 0) {
            String[] lines = raw.split("\n");
            for (int i = 0; i < lines.length; i++) {
                int tab = lines[i].indexOf('\t');
                if (tab > 0) {
                    list.add(new Item(lines[i].substring(tab + 1), lines[i].substring(0, tab)));
                }
            }
        }
        Collections.sort(list, new Comparator<Item>() {
            public int compare(Item a, Item b) {
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        return list;
    }

    /** 同じIPがあれば上書き */
    public static void save(Context c, String name, String ip) {
        List<Item> list = load(c);
        List<Item> out = new ArrayList<Item>();
        for (int i = 0; i < list.size(); i++) {
            if (!list.get(i).ip.equals(ip)) {
                out.add(list.get(i));
            }
        }
        out.add(new Item(clean(name), ip));
        write(c, out);
    }

    public static void remove(Context c, String ip) {
        List<Item> list = load(c);
        List<Item> out = new ArrayList<Item>();
        for (int i = 0; i < list.size(); i++) {
            if (!list.get(i).ip.equals(ip)) {
                out.add(list.get(i));
            }
        }
        write(c, out);
    }

    /** 登録がなければnull */
    public static String nameFor(Context c, String ip) {
        if (ip == null || ip.length() == 0) {
            return null;
        }
        List<Item> list = load(c);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).ip.equals(ip)) {
                return list.get(i).name;
            }
        }
        return null;
    }

    private static void write(Context c, List<Item> list) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) {
                sb.append('\n');
            }
            sb.append(list.get(i).ip).append('\t').append(list.get(i).name);
        }
        prefs(c).edit().putString(KEY, sb.toString()).apply();
    }

    /** 区切り文字(タブ・改行)を除く */
    private static String clean(String name) {
        return name.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
